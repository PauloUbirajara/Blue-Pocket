package unifor.com.bluepocket.entity

data class User(
    var name: String,
    var email: String,
    var userId: String = ""
)