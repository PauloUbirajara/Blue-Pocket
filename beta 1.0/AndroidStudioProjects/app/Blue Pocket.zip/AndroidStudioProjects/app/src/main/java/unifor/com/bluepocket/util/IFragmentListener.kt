package unifor.com.bluepocket.util

import android.view.View

interface IFragmentListener {
    fun onFragmentClick(view: View)
}