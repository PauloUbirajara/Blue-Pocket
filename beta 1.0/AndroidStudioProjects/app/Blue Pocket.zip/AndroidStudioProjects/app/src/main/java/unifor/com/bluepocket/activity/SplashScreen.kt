package unifor.com.bluepocket.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import unifor.com.bluepocket.R
import unifor.com.bluepocket.activity.StartActivity

class SplashScreen : AppCompatActivity() {
    private lateinit var handler: Handler
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        handler = Handler()

        handler.postDelayed({
            val it = Intent(this, StartActivity::class.java)
            startActivity(it)
            finish()
        }, 3000)
    }
}
