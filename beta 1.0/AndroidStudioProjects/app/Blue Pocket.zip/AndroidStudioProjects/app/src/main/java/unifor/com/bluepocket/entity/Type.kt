package unifor.com.bluepocket.entity

data class Type(
    var name: String = "",
    var typeIndicator: String = ""
)