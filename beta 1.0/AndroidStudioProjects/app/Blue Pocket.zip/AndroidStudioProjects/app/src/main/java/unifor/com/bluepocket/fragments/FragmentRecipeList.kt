package unifor.com.bluepocket.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import unifor.com.bluepocket.R

class FragmentRecipeList : Fragment() {
    private lateinit var recyclerView: RecyclerView
    //private lateinit var floatButton: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_recipe_list, container, false)

        recyclerView = view.findViewById(R.id.main_framelayout_container)
        //floatButton = view.findViewById(R.id.) // botao ao lado do nome

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        // floatButton.setOnClickListener {
        //  fragmentListener?.onFragmentClick(it)
        // }
    }

    override fun onStart() {
        super.onStart()
        // codigo
    }

//    fun addFragmentListener(listener: IFragmentListener) {
//        this.fragmentListener = listener
//    }
}