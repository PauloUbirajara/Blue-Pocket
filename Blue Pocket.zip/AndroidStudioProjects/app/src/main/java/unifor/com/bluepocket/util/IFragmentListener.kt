package unifor.com.bluepocket.util

import android.view.View
import unifor.com.bluepocket.entity.Type

interface IFragmentListener {
    fun onFragmentClick(view: View)

    fun onExpenseDelete(position: Int)
    fun onTypeDelete(position: Int)
}