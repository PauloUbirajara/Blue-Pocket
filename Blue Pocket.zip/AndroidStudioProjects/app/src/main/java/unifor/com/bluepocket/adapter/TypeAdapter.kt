package unifor.com.bluepocket.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import unifor.com.bluepocket.R
import unifor.com.bluepocket.entity.Type
import unifor.com.bluepocket.util.IFragmentListener

class TypeAdapter(val context: Context, private val types: List<Type>, val listener: IFragmentListener):RecyclerView.Adapter<TypeAdapter.TypeViewholder>(){

    private val layoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    private lateinit var mAuth: FirebaseAuth

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TypeViewholder {
        val view: View = layoutInflater.inflate(R.layout.item_type, parent, false)

        val typeViewholder = TypeViewholder(context, view, listener)
        return typeViewholder
    }

    override fun getItemCount(): Int {
        return types.size
    }

    override fun onBindViewHolder(holder: TypeViewholder, position: Int) {
        holder.listName.text = types[position].name
        holder.listIndicator.text = types[position].typeIndicator
        holder.deleteType.setOnClickListener {

        }
    }

    class TypeViewholder(val context: Context, val view: View, val listener: IFragmentListener): RecyclerView.ViewHolder(view) {
        var listName:TextView = view.findViewById(R.id.item_textview_typename)
        var listIndicator:TextView = view.findViewById(R.id.item_textview_typeindicator)
        var deleteType: ImageView = view.findViewById(R.id.item_textview_deletetype)
    }
}