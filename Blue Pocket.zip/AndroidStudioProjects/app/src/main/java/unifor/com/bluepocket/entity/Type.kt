package unifor.com.bluepocket.entity

import unifor.com.bluepocket.enum.TypeValue

data class Type(
    var userId: String = "",
    var name: String = "",
    var typeIndicator: String = ""
)