package unifor.com.bluepocket.activity

import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import br.unifor.cct.droidtodo.fragments.FragmentTypeList
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import unifor.com.bluepocket.R
import unifor.com.bluepocket.entity.Type
import unifor.com.bluepocket.fragments.FragmentTypeRegister
import unifor.com.bluepocket.util.IFragmentListener

class TypeMainActivity : AppCompatActivity(), IFragmentListener {
    // Adicionar o botao pra cada categoria lateral
    private lateinit var mAuth: FirebaseAuth
    private lateinit var mDatabase: FirebaseDatabase
    var userId: String = ""
    var typeId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_type)

        mAuth = FirebaseAuth.getInstance()
        mDatabase = FirebaseDatabase.getInstance()

        userId = mAuth.currentUser!!.uid

        val fragmentTypeList = FragmentTypeList(userId) // Mostrar todas as categorias pelo id do usuário logado no momento
        fragmentTypeList.addFragmentListener(this)

        supportFragmentManager.beginTransaction()
            .replace(R.id.types_main_framelayout, fragmentTypeList)
            .addToBackStack(null)
            .commit()
    }

    override fun onFragmentClick(view: View) {
        userId = mAuth.currentUser!!.uid

        when (view.id) {
            R.id.fragment_type_list_floatingbutton_add -> {
                val fragmentTypeRegister = FragmentTypeRegister(userId) // Registro de uma nova categoria

                supportFragmentManager.beginTransaction()
                    .replace(R.id.types_main_framelayout, fragmentTypeRegister)
                    .addToBackStack(null)
                    .commit()
            }
        }
    }

    override fun onExpenseDelete(position: Int) {
    }

    override fun onTypeDelete(position: Int) {
    }
}