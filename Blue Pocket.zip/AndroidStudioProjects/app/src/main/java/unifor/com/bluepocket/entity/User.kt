package unifor.com.bluepocket.entity

data class User(
    var userId: String = "",
    var name: String,
    var email: String
)