package unifor.com.bluepocket.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import unifor.com.bluepocket.R

class ChartMainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chart)
    }
}