package unifor.com.bluepocket.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.view.children
import androidx.fragment.app.Fragment
import com.google.firebase.database.FirebaseDatabase
import unifor.com.bluepocket.R
import unifor.com.bluepocket.entity.Type
import unifor.com.bluepocket.enum.TypeValue


class FragmentTypeRegister(private var userId: String) : Fragment() {
    private lateinit var registerName: EditText
    private lateinit var registerTypeIndicatorRadioGroup: RadioGroup
    private lateinit var registerAdd: Button
    private lateinit var registerBack: Button
    private var typeIndicator: String = ""

    private lateinit var mDatabase: FirebaseDatabase

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_type_register, container, false)

        registerName = view.findViewById(R.id.typeregister_typename_textview)
        registerTypeIndicatorRadioGroup = view.findViewById(R.id.typeregister_radiogroup)

        registerAdd = view.findViewById(R.id.typeregister_typecreate_button)
        registerBack = view.findViewById(R.id.typeregister_typeback_button)

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        registerBack.setOnClickListener {
            activity!!.supportFragmentManager.popBackStack()
        }

        registerAdd.setOnClickListener {
            val index = registerTypeIndicatorRadioGroup.indexOfChild(activity!!.findViewById(registerTypeIndicatorRadioGroup.getCheckedRadioButtonId()))
            Log.i("debug", index.toString() + " - INDEX SELECIONADO") // -1 se ningúem selecionado / 0 para receita e 1 para despesa //

            if (registerName.text.isEmpty()) {
                registerName.error = "Este campo não pode ser nulo"
            } else if(index == -1) {
                val dialog = AlertDialog.Builder(context!!)
                    .setTitle("Erro")
                    .setMessage("Para criar um tipo, é preciso escolher o seu identificador!")
                    .setCancelable(false)
                    .setNeutralButton(
                        "Ok"
                    ) { dialog, id ->
                        dialog.dismiss()
                    }.create()
                dialog.show()
            } else {
                val name = registerName.text.toString()

                val typeRef = mDatabase.getReference("types") // criar pasta categories no database

                val typeId = typeRef.push().key // criar chave aleatória

                val type = Type(name = name, userId = userId)
                if(index == 0) {
                    type.typeIndicator = TypeValue.RECEITA.toString()
                } else {
                    type.typeIndicator = TypeValue.DESPESA.toString()
                }

                typeRef.child(typeId!!).setValue(type).addOnCompleteListener {

                    if (it.isSuccessful) {
                        val dialog = AlertDialog.Builder(context!!)
                            .setTitle("Criação de Tipo")
                            .setMessage("Tipo criada com sucesso!")
                            .setCancelable(false)
                            .setNeutralButton(
                                "Ok"
                            ) { dialog, id ->
                                dialog.dismiss()
                                activity!!.supportFragmentManager.popBackStack()
                            }.create()

                        dialog.show()
                    } else {
                        val dialog = AlertDialog.Builder(context!!)
                            .setTitle("Erro ao criar tipo")
                            .setMessage("${it.exception!!.message}!")
                            .setCancelable(false)
                            .setNeutralButton(
                                "Ok"
                            ) { dialog, id ->
                                dialog.dismiss()
                                activity!!.supportFragmentManager.popBackStack()

                            }.create()

                        dialog.show()
                    }
                }
            }
        }
    }
    override fun onStart() {
        super.onStart()
        mDatabase = FirebaseDatabase.getInstance()
    }
}
