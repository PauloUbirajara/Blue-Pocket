package unifor.com.bluepocket.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.google.firebase.database.FirebaseDatabase
import unifor.com.bluepocket.R
import unifor.com.bluepocket.entity.Expense

class FragmentExpenseRegister(private var userId: String) : Fragment() {
    private lateinit var registerName: EditText
    private lateinit var selectTypeButton: Button
    private lateinit var selectedType: TextView
    private lateinit var registerDate: EditText
    private lateinit var registerValue: EditText
    private lateinit var registerAdd: Button
    private lateinit var registerBack: Button
    private val RECIPE_ID = 0
    private val EXPENSE_ID = 1

    private lateinit var mDatabase: FirebaseDatabase

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_expense_register, container, false)

        registerName = view.findViewById(R.id.expenseregister_expensename_textview)
        selectTypeButton = view.findViewById(R.id.expenseregister_typeselect_button)
        selectedType = view.findViewById(R.id.expenseregister_selectedtype_textview)
        registerDate = view.findViewById(R.id.expenseregister_expensedate_textview)
        registerValue = view.findViewById(R.id.expenseregister_expensevalue_textview)

        registerAdd = view.findViewById(R.id.expenseregister_expensecreate_button)
        registerBack = view.findViewById(R.id.expenseregister_expenseback_button)

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        selectTypeButton.setOnClickListener {
//            val it = Intent(activity, ChooseTypeActivity::class.java)
//            startActivityForResult(it, EXPENSE_ID) // 0 - Receita / 1 - Despesa //
        }

        registerBack.setOnClickListener {
            activity!!.supportFragmentManager.popBackStack()
        }

        registerAdd.setOnClickListener {
            if (registerName.text.isEmpty()) {
                registerName.error = "Este campo não pode ser nulo"
            } else if(selectedType.text.isEmpty()) {
                selectedType.error = "É preciso selecionar um tipo para a despesa"
            } else if (registerDate.text.isEmpty()) {
                registerDate.error = "Este campo não pode ser nulo"
            } else if (registerValue.text.isEmpty()) {
                registerValue.error = "Este campo não pode ser nulo"
            } else {
                val name = registerName.text.toString()

                val expenseRef = mDatabase.getReference("expenses") // criar pasta despesas no database

                val expenseId = expenseRef.push().key // criar chave aleatória

                val expense = Expense(name = name, userId = userId)

                expenseRef.child(expenseId!!).setValue(expense).addOnCompleteListener {

                    if (it.isSuccessful) {
                        val dialog = AlertDialog.Builder(context!!)
                            .setTitle("Criação de Despesa")
                            .setMessage("Despesa criada com sucesso!")
                            .setCancelable(false)
                            .setNeutralButton(
                                "Ok"
                            ) { dialog, id ->
                                dialog.dismiss()
                                activity!!.supportFragmentManager.popBackStack()
                            }.create()

                        dialog.show()
                    } else {
                        val dialog = AlertDialog.Builder(context!!)
                            .setTitle("Erro ao criar despesa")
                            .setMessage("${it.exception!!.message}!")
                            .setCancelable(false)
                            .setNeutralButton(
                                "Ok"
                            ) { dialog, id ->
                                dialog.dismiss()

                            }.create()

                        dialog.show()
                    }
                }
            }
        }

        registerBack.setOnClickListener {
            activity!!.supportFragmentManager.popBackStack()
        }
    }

    override fun onStart() {
        super.onStart()
        mDatabase = FirebaseDatabase.getInstance()
    }
}
