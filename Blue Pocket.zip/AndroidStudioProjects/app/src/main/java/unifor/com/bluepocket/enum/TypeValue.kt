package unifor.com.bluepocket.enum

enum class TypeValue(val tipo: String) {
    RECEITA("RECEITA"),
    DESPESA("DESPESA")
}